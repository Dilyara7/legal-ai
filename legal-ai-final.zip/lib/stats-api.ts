// lib/stats-api.ts
export interface UserStats {
  totalConsultations: number
  completedConsultations: number
  totalSpent: number
  currentBalance: number
}