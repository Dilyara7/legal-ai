export default function ForgotPasswordPage() {
  return null
}
