"use client"

import ForgotPasswordForm from "@/components/forgot-password-form"

export default function ForgotPasswordClientPage() {
  return <ForgotPasswordForm />
}
