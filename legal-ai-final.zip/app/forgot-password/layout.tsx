import ClientPage from "./client-page"

export default function ForgotPasswordLayout() {
  return <ClientPage />
}
