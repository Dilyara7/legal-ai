export default function RegisterPage() {
  return null
}
