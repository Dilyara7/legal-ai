import ClientPage from "./client-page"

export default function RegisterLayout() {
  return <ClientPage />
}
