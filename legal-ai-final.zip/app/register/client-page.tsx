"use client"

import RegisterForm from "@/components/register-form"

export default function RegisterClientPage() {
  return <RegisterForm />
}
