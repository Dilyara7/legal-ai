import ClientPage from "./client-page"

export default function LoginLayout() {
  return <ClientPage />
}
